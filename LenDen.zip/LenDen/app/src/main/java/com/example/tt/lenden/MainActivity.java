package com.example.tt.lenden;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getActionBar().setTitle("   Len Den");
        TextView t = (TextView)findViewById(R.id.test);
        t.setText(Integer.toString(getActivity()));


    }
    public void StartJourney(View view) {
        Intent intent = new Intent(this,select.class);
        Bundle bundle = new Bundle();
        EditText editText = (EditText) findViewById(R.id.journey);
        String message = editText.getText().toString();
        if(message==null || message.trim().equals("")){
            Toast.makeText(getBaseContext(), " Please enter a Journey Name ", Toast.LENGTH_SHORT).show();
        }
        else{
            setActivity();
            //Add your data from getFactualResults method to bundle
            //bundle.putString("journey_name", message);
            //Add the bundle to the intent
            saveJourneyName(message);
            intent.putExtras(bundle);
            startActivity(intent);
            finish();
        }
    }

    private void saveJourneyName(String name) {
        SharedPreferences p = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        SharedPreferences.Editor edit = p.edit();
        edit.putString("journey_name",name);
        edit.commit();
    }

    public void setActivity(){
        int current = getActivity();
        current++;
        SharedPreferences p = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        SharedPreferences.Editor edit = p.edit();
        edit.putInt("current_activity", current);
        edit.commit();
    }
    public int getActivity(){
        int c;
        SharedPreferences pref= PreferenceManager.getDefaultSharedPreferences(getBaseContext());
        c = pref.getInt("current_activity",1);
        return c;
    }

}
