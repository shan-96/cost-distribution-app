package com.example.tt.lenden;

import android.annotation.TargetApi;
import android.app.ListActivity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v7.app.ActionBar;
import android.util.SparseBooleanArray;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckedTextView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class checkboxes extends ListActivity implements View.OnClickListener{
    String[] arr;
    String name;
    ListView listview;
    Button btn;

    @TargetApi(Build.VERSION_CODES.JELLY_BEAN_MR2)
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_checkboxes);

        getActionBar().setDisplayHomeAsUpEnabled(true);
        getActionBar().setHomeAsUpIndicator(R.drawable.go_back);
        getActionBar().setTitle("   Len Den");

       /*ActionBar actionBar = getSupportActionBar();                                  //action bar stuffs
        actionBar.setLogo(R.drawable.applogo);
        actionBar.setTitle("   LenDen");
        //actionBar.setBackgroundDrawable(new ColorDrawable(Color.GREEN));
        actionBar.setDisplayUseLogoEnabled(true);
        actionBar.setDisplayShowHomeEnabled(true);*/

        TextView t = (TextView)findViewById(R.id.test);
        t.setText(Integer.toString(getActivity()));

        btn = (Button)findViewById(R.id.btn);
        btn.setOnClickListener(this);

        Bundle b = getIntent().getExtras();
        name = b.getString("name");
        int key = b.getInt("btn");

        if(key==1)  //add people
        {
            storeData(name);
            arr = getData();
            display(arr);
        }else{
            arr = getData();
            display(arr);
        }
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                // app icon in action bar clicked; go home
                Intent intent = new Intent(this, select.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
    private int getPersonCount(){
        SharedPreferences pref= PreferenceManager.getDefaultSharedPreferences(getBaseContext());
        String check=pref.getString("person_count", "0");
        int count = Integer.parseInt(check);
        return count;
    }
    private String getPersonName(int id){
        SharedPreferences p= PreferenceManager.getDefaultSharedPreferences(getBaseContext());
        String name = p.getString(Integer.toString(id), "No name");
        return name;
    }
    private void incrPersonCount(){
        int count = getPersonCount();
        count++;
        SharedPreferences cp= PreferenceManager.getDefaultSharedPreferences(getBaseContext());
        SharedPreferences.Editor e = cp.edit();
        e.putString("person_count", Integer.toString(count));
        e.commit();
    }
    private void addNameToList(int id, String name){
        SharedPreferences p = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        SharedPreferences.Editor edit = p.edit();
        edit.putString(Integer.toString(id), name);
        edit.commit();
    }

    private void storeData(String name) {
        incrPersonCount();
        int newId = getPersonCount();
        addNameToList(newId, name);
        Toast.makeText(this, name+" saved with id "+newId, Toast.LENGTH_LONG).show();
    }

    private String[] getData(){
        int count = getPersonCount();
        String arr[] = new String[count+1];
        arr[0] = "Select All";
        for(int i=1;i<=count;i++){
            arr[i] = getPersonName(i);
        }
        return  arr;
    }


    public void onListItemClick(ListView parent, View v,int position,long id){
        if(position==0){
            if(parent.isItemChecked(0)){
                for(int i=0;i<arr.length;i++){
                    listview.setItemChecked(i,true);
                    Toast.makeText(this,"All Selected", Toast.LENGTH_SHORT).show();
                }
            }else{
                for(int i=0;i<arr.length;i++){
                    listview.setItemChecked(i,false);
                    Toast.makeText(this,"All Deselected", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }

    void display(String[] arr){
        // -- Display mode of the ListView
        listview= getListView();
        listview.setChoiceMode(listview.CHOICE_MODE_MULTIPLE);
        listview.setTextFilterEnabled(true);
        setListAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_list_item_checked, arr));

    }

    @Override
    public void onClick(View v) {
        int[] pos = new int[arr.length];
        int count=0;
        if(v.getId() == R.id.btn){
            for(int i=1;i<arr.length;i++) {
                if (listview.isItemChecked(i)) {
                    pos[count++] = i;
                }
            }
            savePeoplesForJourney(pos, count);
            setActivity();
            Intent intent = new Intent(checkboxes.this, Expense.class);
            startActivity(intent);
            finish();
        }
    }

    private void savePeoplesForJourney(int[] pos, int count) {
        saveCurrentJourneyPeopleCount(count);
        saveCurrentJourneyPeoplename(pos, count);
        saveCurrentJourneyPeopleDebit(count);
        saveCurrentJourneyPeopleCredit(count);

        //createBeneficiaries(count);
    }

    /*private void createBeneficiaries(int count) {
        for(int i=1;i<=count;i++){
            for(int j=1;j<=count;j++){
                if(i!=j){
                    SharedPreferences p = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
                    SharedPreferences.Editor edit = p.edit();
                    edit.putFloat("ToCurrent_p"+i+j,0);
                    edit.commit();
                }
            }
        }
    }*/

    private void saveCurrentJourneyPeopleCredit(int count) {
        for(int i=0;i<count;i++){
            SharedPreferences p = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
            SharedPreferences.Editor edit = p.edit();
            edit.putFloat("credit"+Integer.toString(i+1),0);            //id of journey list
            edit.commit();
        }
    }

    private void saveCurrentJourneyPeopleDebit(int count) {
        for(int i=0;i<count;i++){
            SharedPreferences p = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
            SharedPreferences.Editor edit = p.edit();
            edit.putFloat("debit"+Integer.toString(i+1),0);             //id of journey list
            edit.commit();
        }
    }

    private void saveCurrentJourneyPeoplename(int[] pos, int count) {
        for(int i=0;i<count;i++){
            SharedPreferences p = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
            SharedPreferences.Editor edit = p.edit();
            edit.putString("current_p" + Integer.toString(i + 1), getPersonName(pos[i]));
            edit.commit();
        }
    }

    private void saveCurrentJourneyPeopleCount(int count) {
        SharedPreferences p = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        SharedPreferences.Editor edit = p.edit();
        edit.putInt("current_count", count);
        edit.commit();
    }
    public void setActivity(){
        int current = getActivity();
        current+=2;
        SharedPreferences p = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        SharedPreferences.Editor edit = p.edit();
        edit.putInt("current_activity", current);
        edit.commit();
    }
    public int getActivity(){
        int c;
        SharedPreferences pref= PreferenceManager.getDefaultSharedPreferences(getBaseContext());
        c = pref.getInt("current_activity",1);
        return c;
    }
}
