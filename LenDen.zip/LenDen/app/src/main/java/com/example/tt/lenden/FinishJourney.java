package com.example.tt.lenden;

import android.annotation.TargetApi;
import android.app.ActionBar;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.app.Activity;
import android.preference.PreferenceManager;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;

public class FinishJourney extends Activity {

    @TargetApi(Build.VERSION_CODES.JELLY_BEAN_MR2)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);
        add();

        getActionBar().setTitle("   Len Den");
        getActionBar().setLogo(R.drawable.applogo);
        //actionBar.setBackgroundDrawable(new ColorDrawable(Color.GREEN));
        try {
            show();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    private void add() {
        LinearLayout lm = (LinearLayout)findViewById(R.id.lm);
        LinearLayout.LayoutParams params1 = new LinearLayout.LayoutParams(
                ActionBar.LayoutParams.MATCH_PARENT, 100);
        params1.setMargins(0, 20, 0, 0);
        LinearLayout llf = new LinearLayout(this);
        llf.setOrientation(LinearLayout.VERTICAL);
        llf.setLayoutParams(params1);
        //llf.setBackground(R.drawable.border2);

        LinearLayout lls = new LinearLayout(this);
        lls.setOrientation(LinearLayout.HORIZONTAL);
        lls.setWeightSum(100);
        LinearLayout.LayoutParams params2 = new LinearLayout.LayoutParams(
                ActionBar.LayoutParams.MATCH_PARENT, ActionBar.LayoutParams.WRAP_CONTENT);
        lls.setLayoutParams(params2);
        TextView name1 = new TextView(this);
        name1.setText("Name11");
        name1.setTextColor(Color.parseColor("#00FFFF"));
        name1.setTextSize(20);
        name1.setGravity(Gravity.LEFT);

        TextView name2 = new TextView(this);
        name2.setText("Name22");
        name2.setTextColor(Color.parseColor("#00FFFF"));
        name2.setTextSize(20);
        name2.setGravity(Gravity.RIGHT);

        lls.addView(name1);
        lls.addView(name2);

        llf.addView(lls);
        TextView amt = new TextView(this);
        amt.setText("Amount");
        llf.addView(amt);
        lm.addView(llf);


    }

    public void setActivity(){
        SharedPreferences p = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        SharedPreferences.Editor edit = p.edit();
        edit.putInt("current_activity", 1);
        edit.commit();
    }
    public void FinishSession(View v){
        setActivity();
        Intent i = new Intent(FinishJourney.this, MainActivity.class);
        startActivity(i);
    }
    public void show() throws IOException {
        String msg="";
        for(int i=1;i<=getCurrentCout();i++){
            SharedPreferences pref= PreferenceManager.getDefaultSharedPreferences(getBaseContext());
            String from = pref.getString("current_p"+i, "No Name");
            for(int j=1;j<=getKitneCount(i);j++){
                float amt = pref.getFloat("give"+i+j, 0);
                if(amt>0){
                    String to = pref.getString("giveTo"+i+j,"No Name");
                    msg = msg+" "+from+" gives "+amt+" to "+to+"   ";
                }
            }

        }
        msg+="\n\n";
        saveToFile("NEW data ", "file.txt");
        String d = readFIle("file.txt");
        msg+=d;
        TextView tv5 = (TextView)findViewById(R.id.tv5);
        tv5.setText(msg);
    }
    public int getKitneCount(int id){
        SharedPreferences pref= PreferenceManager.getDefaultSharedPreferences(getBaseContext());
        int c = pref.getInt("kitne"+id, 0);
        return c;
    }
    public int getCurrentCout() {
        SharedPreferences pref= PreferenceManager.getDefaultSharedPreferences(getBaseContext());
        int count = pref.getInt("current_count", 0);
        return count;
    }
    public void saveToFile(String data, String filename) {
        FileOutputStream fos = null;
        try {
            fos = openFileOutput(filename, Context.MODE_PRIVATE);
            fos.write(data.getBytes());
            fos.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public String  readFIle(String filename) throws IOException {
        FileInputStream fis = openFileInput(filename);
        InputStreamReader isr = new InputStreamReader(fis);
        BufferedReader bufferedReader = new BufferedReader(isr);
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = bufferedReader.readLine()) != null) {
            sb.append(line);
        }
        return sb.toString();
    }


}
