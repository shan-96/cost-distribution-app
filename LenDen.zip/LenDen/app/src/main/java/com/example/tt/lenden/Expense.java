package com.example.tt.lenden;


import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 * Created by shantanu on 10-03-2016.
 */
public class Expense extends AppCompatActivity {
    LinearLayout lm;
    String[] names;
    Spinner s;
    int count;
    ListView listview;
    private int currentCout;

    String spentBy;
    int spentByPersonId;
    float spentMoney;
    String spentDesc;
    int[] spentOn;
    int onSpentCount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.expense);
        lm = (LinearLayout)findViewById(R.id.lm);
        getCheckedItems();
        s = (Spinner)findViewById(R.id.spinner);
        addInSpinner(names);
        displayList(names);
        //add();
        ActionBar actionBar = getSupportActionBar();
        actionBar.setLogo(R.drawable.applogo);
        actionBar.setTitle("   LenDen");
        //actionBar.setBackgroundDrawable(new ColorDrawable(Color.GREEN));
        actionBar.setDisplayUseLogoEnabled(true);
        actionBar.setDisplayShowHomeEnabled(true);
        /*TextView t = (TextView)findViewById(R.id.test);
        t.setText(Integer.toString(getActivity()));*/
    }

    void displayList(String[] names){
        listview=(ListView)findViewById(R.id.listView);
        listview.setChoiceMode(listview.CHOICE_MODE_MULTIPLE);
        listview.setTextFilterEnabled(true);
        listview.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_list_item_checked, names));
        listview.setOnTouchListener(new View.OnTouchListener() {
            // Setting on Touch Listener for handling the touch inside ScrollView
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                // Disallow the touch request for parent scroll on touch of child view
                v.getParent().requestDisallowInterceptTouchEvent(true);
                return false;
            }
        });
    }

    private void addInSpinner(String[] name){
        ArrayAdapter<String> x;
        x = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, name);
        s.setAdapter(x);
        x.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
    }
    private void getCheckedItems(){
        count = getCurrentCout();
        names = new String[count];
        for(int i=0;i<count;i++){
            names[i] = new String(getCurrentNames(i + 1));
        }
    }
    public String getCurrentNames(int i) {
        SharedPreferences pref= PreferenceManager.getDefaultSharedPreferences(getBaseContext());
        String n = pref.getString("current_p" + Integer.toString(i), "No Name");
        return n;
    }



    public int getCurrentCout() {
        SharedPreferences pref= PreferenceManager.getDefaultSharedPreferences(getBaseContext());
        int count = pref.getInt("current_count", 0);
        return count;
    }
    public float getDebit(int id){
        SharedPreferences pref= PreferenceManager.getDefaultSharedPreferences(getBaseContext());
        float d = pref.getFloat("debit" + id, 0);
        return d;
    }
    public float getCredit(int id){
        SharedPreferences pref= PreferenceManager.getDefaultSharedPreferences(getBaseContext());
        float d = pref.getFloat("credit" + id, 0);
        return d;
    }
    public void incDebit(int id, float d){
        float newDebit = getDebit(id) + d;
        SharedPreferences p = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        SharedPreferences.Editor edit = p.edit();
        edit.putFloat("debit"+Integer.toString(id), newDebit);
        edit.commit();
    }
    public void incCredit(int id, float c){
        float newCredit = getCredit(id)+c ;
        SharedPreferences p = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        SharedPreferences.Editor edit = p.edit();
        edit.putFloat("credit"+Integer.toString(id), newCredit);
        edit.commit();
    }
    public void decDebit(int id, float d){
        float newDebit = getDebit(id) - d;
        SharedPreferences p = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        SharedPreferences.Editor edit = p.edit();
        edit.putFloat("debit"+Integer.toString(id), newDebit);
        edit.commit();
    }
    public void decCredit(int id, float c){
        float newCredit = getCredit(id)-c ;
        SharedPreferences p = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        SharedPreferences.Editor edit = p.edit();
        edit.putFloat("credit"+Integer.toString(id), newCredit);
        edit.commit();
    }
    public void save(View view){
        Spinner s_name;
        s_name = (Spinner)findViewById(R.id.spinner);
        spentBy = s_name.getSelectedItem().toString();
        spentByPersonId = s_name.getSelectedItemPosition();

        EditText et_money,et_desc ;
        et_money = (EditText)findViewById(R.id.editText);
        String mny = et_money.getText().toString();


        et_desc = (EditText)findViewById(R.id.editText3);
        spentDesc = et_desc.getText().toString();

        spentOn = new int[count];
        onSpentCount=0;
        for(int i=0;i<count;i++){
            if(listview.isItemChecked(i)){
                spentOn[onSpentCount++] = i;
                Toast.makeText(this, "Saved Successfully", Toast.LENGTH_SHORT).show();
            }
        }

       if(mny.length()==0){
           Toast.makeText(this, "Please Enter Amount", Toast.LENGTH_SHORT).show();
       }else if(onSpentCount<1){
           Toast.makeText(this, "Please Select The Peoples On Which Money has been spent", Toast.LENGTH_SHORT).show();
       }else{
           spentMoney = Float.parseFloat(mny);
           incDebit(spentByPersonId + 1, spentMoney);        //Increment debit of person who spent money
           ManageCreditDebit(spentMoney, spentOn);
       }
        //ManageTransactions(spentByPersonId, spentMoney, spentOn);

        /*TextView tv1 = (TextView)findViewById(R.id.tv1);
        TextView tv2 = (TextView)findViewById(R.id.tv2);
        TextView tv3 = (TextView)findViewById(R.id.tv3);
        TextView tv4 = (TextView)findViewById(R.id.tv4);*/
        //TextView tv5 = (TextView)findViewById(R.id.tv5);

        /*tv1.setText(Float.toString(getCredit(1))+" "+Float.toString(getDebit(1)) );
        tv2.setText(Float.toString(getCredit(2))+" "+Float.toString(getDebit(2)));
        tv3.setText(Float.toString(getCredit(3))+" "+Float.toString(getDebit(3)));
        tv4.setText(Float.toString(getCredit(4))+" "+Float.toString(getDebit(4)));*/
        //tv5.setText(Float.toString(getCredit(5))+" "+Float.toString(getDebit(5)));
        showResult();
    }

    /*private void ManageTransactions(int id, float spentMoney, int[] spentOn) {

        float avg = spentMoney/onSpentCount;
        for(int i=0;i<onSpentCount;i++){
            if(id != spentOn[i]){
                setUpTransaction(spentOn[i], id, avg);
            }
        }
    }*/
    /*private void setUpTransaction(int donorId, int receiverId, float amt){
        float newAmt = getAmt(donorId,receiverId)+amt;

        int u = donorId+1;
        int v = receiverId+1;
        SharedPreferences p = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        SharedPreferences.Editor edit = p.edit();
        edit.putFloat("ToCurrent_p"+u+v,newAmt);
        edit.commit();
    }*/
    /*private float getAmt(int donorId, int receiverId){
        SharedPreferences pref= PreferenceManager.getDefaultSharedPreferences(getBaseContext());
        int u = donorId+1;
        int v = receiverId+1;
        float amt = pref.getFloat("ToCurrent_p"+u+v,0);
        return amt;
    }*/


    private void ManageCreditDebit(float amt, int[] spentOn) {
        float avg = amt/onSpentCount;
        for(int i=0;i<onSpentCount;i++){
            incCredit(spentOn[i]+1, avg);
        }
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        super.onCreateOptionsMenu(menu);
        getMenuInflater().inflate(R.menu.on_journey_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        switch (item.getItemId()){
            case R.id.finish:
                setActivity();
                Intent i = new Intent(Expense.this, FinishJourney.class);

                Toast.makeText(getBaseContext(), "Journey Finished.. Hope You Enjoyed", Toast.LENGTH_SHORT).show();
                startActivity(i);
                break;
            case R.id.currentStatus:
                Toast.makeText(getBaseContext(), "Current Status Of Journey", Toast.LENGTH_SHORT).show();
                break;
            case R.id.exit:
                finish();
                break;

        }
        return false;


    }
    public void setActivity(){
        int current = getActivity();
        current++;
        SharedPreferences p = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        SharedPreferences.Editor edit = p.edit();
        edit.putInt("current_activity", current);
        edit.commit();
    }
    public int getActivity(){
        int c;
        SharedPreferences pref= PreferenceManager.getDefaultSharedPreferences(getBaseContext());
        c = pref.getInt("current_activity",1);
        return c;
    }
    public void showResult(){
        count = getCurrentCout();
        calculation[] c = new calculation[count] ;
        int k=0;

        for(int i=0;i<count;i++){
            c[i]= new calculation(count,getCurrentNames(i+1), getCredit(i+1),getDebit(i+1) );
        }

        /*c[0] = new calculation(5,"Tarun",15,30);					//params  count, name, credit, debit
        c[1] = new calculation(5,"sarang",10,15);
        c[2] = new calculation(5,"sarfraz",15,0);
        c[3] = new calculation(5,"jigmat", (float) 7.5,0);
        c[4] = new calculation(5,"anurag", (float) 12.5,15);*/

        calc(c);
        String msg="";
        for(int i=0;i<count;i++)
        {
            for(k=0;k<c[i].kitne;k++){
                if(c[i].give[k] != 0){
                    saveTransaction(i+1, k+1, c[i].giveThem[k],c[i].give[k]);
                   // msg+=c[i].name+" gives Rs "+c[i].give[k]+" to "+c[i].giveThem[k]+"  ";
                    //System.out.println(c[i].name+" gives Rs"+c[i].give[k]+" to "+c[i].giveThem[k]);
                }
            }
        }
        //rough displaying
        /*for(int i=1;i<=count;i++){
            SharedPreferences pref= PreferenceManager.getDefaultSharedPreferences(getBaseContext());
            String from = pref.getString("current_p"+i, "No Name");
            for(int j=1;j<=getKitneCount(i);j++){
                float amt = pref.getFloat("give"+i+j, 0);
                if(amt>0){
                    String to = pref.getString("giveTo"+i+j,"No Name");
                    msg = msg+" "+from+" gives "+amt+" to "+to+"   ";
                }
            }

        }
        msg+="\n\n";
        TextView tv5 = (TextView)findViewById(R.id.tv5);
        tv5.setText(msg);*/

    }
    public int getKitneCount(int id){
        SharedPreferences pref= PreferenceManager.getDefaultSharedPreferences(getBaseContext());
        int c = pref.getInt("kitne"+id, 0);
        return c;
    }
    public void saveTransaction(int fromId, int toId, String receiver, float amt){
        SharedPreferences p = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        SharedPreferences.Editor edit = p.edit();
        edit.putFloat("give"+fromId+toId, amt);
        edit.putString("giveTo" + fromId + toId, receiver);
        edit.commit();
    }
    public void upadateKitneCount(int id, int kitne){
        SharedPreferences p = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        SharedPreferences.Editor edit = p.edit();
        edit.putInt("kitne" + id, kitne);
        edit.commit();
    }

    public void calc(calculation c[]){
        int i,j,k=0;
        int count = getCurrentCout();
        for(i=0;i<count;i++){
            if(c[i].credit > c[i].debit){
                c[i].credit = c[i].credit - c[i].debit;
                c[i].debit = 0;
            }
            else{
                c[i].debit = c[i].debit - c[i].credit;
                c[i].credit = 0;
            }
        }
        for(i=0;i<count;i++)
        {
            for(j=i+1;j<count;j++)
            {
                if(c[i].getDebit()>0 && c[j].getCredit()>0)
                {
                    if(c[i].getDebit()-c[j].getCredit()>0)
                    {
                        //give[k] = new double();
                        c[i].decDebit(c[j].getCredit());
                        c[j].give[c[j].kitne]=c[j].getCredit();//give[j+1]=getDebit(j+1);
                        c[j].decCredit(c[j].getCredit());
                        c[j].giveThem[c[j].kitne]=c[i].name;
                        //giveThem[]=name[i];
                        //System.out.println(c[j].name+" pays Rs "+c[j].give[c[j].kitne]+" to "+c[i].name);
                        (c[j].kitne)++;
                        //cout<<endl<<p[j].name<<" pays "<<"Rs "<<p[j].give<<" to "<<p[i].name;
                    }
                    else
                    {
                        c[j].decCredit(c[i].getDebit());
                        c[j].give[(c[j].kitne)]=c[i].getDebit();//give[j+1]=getCredit(i+1);
                        c[i].decDebit(c[i].getDebit());
                        c[j].giveThem[c[j].kitne]=c[i].name;
                        //System.out.println(c[j].name+" pays Rs "+c[j].give[c[j].kitne]+" to "+c[i].name);
                        (c[j].kitne)++;
                        //cout<<endl<<p[j].name<<" pays "<<"Rs "<<p[j].give<<" to "<<p[i].name;
                    }
                }
                if(c[i].getCredit()>0 && c[j].getDebit()>0)
                {
                    if(c[j].getDebit()-c[i].getCredit()>0)
                    {
                        c[j].decDebit(c[i].getCredit());
                        c[i].give[(c[i].kitne)]=c[i].getCredit();//give[i+1]=getDebit(i+1);
                        c[i].decCredit(c[i].getCredit());
                        c[i].giveThem[c[i].kitne]=c[j].name;
                        //System.out.println(c[i].name+" pays Rs "+c[i].give[(c[i].kitne)]+" to "+c[j].name);
                        (c[i].kitne)++;
                        //cout<<endl<<p[i].name<<" pays "<<"Rs "<<p[i].give<<" to "<<p[j].name;
                    }
                    else
                    {
                        c[i].decCredit(c[j].getDebit());
                        c[i].give[(c[i].kitne)]=c[j].getDebit();//give[i+1]=getCredit(j+1);
                        c[j].decDebit(c[j].getDebit());
                        c[i].giveThem[c[i].kitne]=c[j].name;
                        //System.out.println(c[i].name+" pays Rs "+c[i].give[(c[i].kitne)]+" to "+c[j].name);
                        c[i].kitne++;
                        //cout<<endl<<p[i].name<<" pays "<<"Rs "<<p[i].give<<" to "<<p[j].name;
                    }
                }
            }
        }
        for(int p=1;p<=count;p++){
            upadateKitneCount(p, c[p-1].kitne);
            Toast.makeText(getBaseContext(), p+" kitne upadated to "+getKitneCount(p), Toast.LENGTH_SHORT).show();
        }

    }



}
