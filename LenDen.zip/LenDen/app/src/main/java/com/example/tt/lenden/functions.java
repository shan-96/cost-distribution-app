package com.example.tt.lenden;

import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;

/**
 * Created by shantanu on 11-03-2016.
 */
public class functions extends AppCompatActivity{

}
