package com.example.tt.lenden;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;

/**
 * Created by shantanu on 07-03-2016.
 */
public class logo extends Activity{
    // Splash screen timer
    private static int SPLASH_TIME_OUT = 500;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.logo);
        new Handler().postDelayed(new Runnable() {

            /*
             * Showing splash screen with a timer. This will be useful when you
             * want to show case your app logo / company
             */

            @Override
            public void run() {
                // This method will be executed once the timer is over
                // Start app main activity
                //Intent i = new Intent(logo.this, MainActivity.class);
                Intent i = currentActivity();
                startActivity(i);

                // close this activity
                finish();
            }
        }, SPLASH_TIME_OUT);
    }
    private Intent currentActivity(){
        //1.  MainActivity   (takes the journey title)
        //2.  select         (select button/ add new people)
        //3.  checkboxes     (select peopel for journey)
        //3.  Expense        (takes each expense of journey)
        //4.  FinishJourney  (show the Results)
        Intent i=new Intent();
        int c = getActivity1();
        switch (c){
            case 1:
                i = new Intent(logo.this, MainActivity.class);          //value 1
                break;
            case 2:
                i = new Intent(logo.this, select.class);                //value 2
                break;
            case 3:
                i = new Intent(logo.this, checkboxes.class);            //value still 2
            case 4:
                i = new Intent(logo.this, Expense.class);               //value 4
                break;
            case 5:
                i = new Intent(logo.this, FinishJourney.class);         //value 5
                break;
            default:
                setActivity();
                i = new Intent(logo.this, MainActivity.class);
        }

        return  i;
    }
    public int getActivity1(){
        int c;
        SharedPreferences pref= PreferenceManager.getDefaultSharedPreferences(getBaseContext());
        c = pref.getInt("current_activity",1);
        return c;
    }
    public void setActivity(){
        SharedPreferences p = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        SharedPreferences.Editor edit = p.edit();
        edit.putInt("current_activity", 1);
        edit.commit();
    }

}
