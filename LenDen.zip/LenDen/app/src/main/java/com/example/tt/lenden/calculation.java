package com.example.tt.lenden;

/**
 * Created by shantanu on 13-03-2016.
 */
public class calculation {
    float credit,debit;
    static int count;
    String[] giveThem = new String[count];
    float[] give = new float[count];
    String name;
    int kitne=0;	//kitne gives no of person to be given money
    public calculation(int c,String name, float credit, float debit){
        count = c;
        this.setName(name);
        this.setCredit(credit);
        this.setDebit(debit);
    }
    public void setName(String name){
        this.name = name;
    }
    public String getgiveThem(int id){
        return giveThem[id-1];
    }
    public float getgive(int id){
        return give[id-1];
    }
    public void setCredit(float credit){
        this.credit = credit;
    }
    public void setDebit(float debit){
        this.debit = debit;
    }
    public float getCredit(){
        return credit;
    }
    public float getDebit(){
        return debit;
    }
    public float decCredit(float amt){
        credit-=amt;
        return credit;
    }
    public float decDebit(float amt){
        debit-=amt;
        return debit;
    }
}
