package com.example.tt.lenden;

import android.app.ListActivity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.app.Activity;
import android.preference.PreferenceManager;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AbsListView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class select extends AppCompatActivity{
    TextView tv;
    private String journeyName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select);

        //getActionBar().setTitle("   Len Den");
        //getActionBar().setLogo(R.drawable.applogo);
        //actionBar.setBackgroundDrawable(new ColorDrawable(Color.GREEN));

        Bundle b = getIntent().getExtras();
        String message = getJourneyName();
        tv = (TextView) findViewById(R.id.textView);
        tv.setText(message);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setLogo(R.drawable.applogo);
        actionBar.setTitle("   LenDen");
        //actionBar.setBackgroundDrawable(new ColorDrawable(Color.GREEN));
        actionBar.setDisplayUseLogoEnabled(true);
        actionBar.setDisplayShowHomeEnabled(true);
        TextView t = (TextView)findViewById(R.id.test);

        t.setText(Integer.toString(getActivity()));
    }
    public void AddPeople(View view) {
        Intent i = new Intent(this,checkboxes.class);
        Bundle bundle = new Bundle();
        EditText editText = (EditText) findViewById(R.id.name);
        String message = editText.getText().toString();
        if(message==null || message.trim().equals("")){
            Toast.makeText(getBaseContext(), "No person added in the list ", Toast.LENGTH_SHORT).show();
        }
        else{
            bundle.putString("name", message);
            bundle.putInt("btn",1);
            //Add the bundle to the intent
            i.putExtras(bundle);
            editText.setText("");
            startActivity(i);
        }

    }
    public void Selected(View view) {
        //setActivity();
        Intent i = new Intent(this,checkboxes.class);
        Bundle bundle = new Bundle();
        bundle.putInt("btn",2);
        i.putExtras(bundle);
        startActivity(i);
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        super.onCreateOptionsMenu(menu);
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        switch (item.getItemId()){
            case R.id.addPeoples:
                Toast.makeText(getBaseContext(), "Please Enter Name And Proceed", Toast.LENGTH_SHORT).show();
                break;
            case R.id.ongoing:
                Toast.makeText(getBaseContext(), "Ongoing Journey", Toast.LENGTH_SHORT).show();
                break;
            case R.id.start:
                Toast.makeText(getBaseContext(), "New Journey Started", Toast.LENGTH_SHORT).show();
                startNewJourney();
                break;
            case R.id.history:
                Toast.makeText(getBaseContext(), "History", Toast.LENGTH_SHORT).show();
                break;
            case R.id.exit:
                finish();
                break;

        }
        return false;


    }

    private void startNewJourney() {
        setActivity();
        Intent i = new Intent(select.this, MainActivity.class);
        startActivity(i);
        finish();
    }

    public void setActivity(){
        SharedPreferences p = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        SharedPreferences.Editor edit = p.edit();
        edit.putInt("current_activity", 1);
        edit.commit();
    }
    public int getActivity(){
        int c;
        SharedPreferences pref= PreferenceManager.getDefaultSharedPreferences(getBaseContext());
        c = pref.getInt("current_activity",1);
        return c;
    }

    public String getJourneyName() {
        String name;
        SharedPreferences pref= PreferenceManager.getDefaultSharedPreferences(getBaseContext());
        name = pref.getString("journey_name", "Failed To Fetch Journey Title, Please Start A New Journey");
        return name;
    }
}
